<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/* nectar addition */ 
/* maybe one day */ 
/* nectar addition end */ 

?>